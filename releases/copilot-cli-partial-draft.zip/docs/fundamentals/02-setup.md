<a id="f2-setup"></a>
# F2. Setup and lifecycle

**Outcomes:** identify prerequisites, choose a documented installation channel and diagnose startup without assuming that access to one Copilot surface implies CLI access. **Prerequisites:** an eligible GitHub account and the ability to install software under your organization's policies.

GitHub's installation page states that Copilot CLI is available with all Copilot plans, subject to the organization's CLI policy when applicable. It lists an active Copilot subscription, PowerShell 6 or later on Windows, and Node.js 22 or later for npm installation. These are documentation findings as of 2026-11-11; account entitlements and this machine's CLI were not successfully tested. [Installation documentation](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli).

## Choose and maintain an installation

The official installation page describes WinGet for Windows, Homebrew for macOS/Linux, npm across platforms, and an install script for macOS/Linux. Follow the current official instructions for your platform and organization, inspect the publisher and installation method, and record the version, channel and install source for reproducibility. Review updates and release notes before adopting them in a managed environment.

**Homebrew discrepancy:** the installation page specifies a cask while the [CLI repository](https://github.com/github/copilot-cli) shows a formula-style invocation. Their equivalence and platform behavior have not been established here. Do not use this draft as a copy-ready Homebrew installation instruction; check current package metadata and test the intended platform first. See [verification ledger V04](../../reference/verification-ledger.md).

No installation commands are published in this draft because none were executed and verified in the target environment. The documentation describes authentication at first launch and use of `/login` when needed; follow its current flow and organizational requirements without exposing tokens in prompts or transcripts. [Installation and authentication](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli).

## Scenario and validation

A Windows team and a Linux CI team want a repeatable environment. Each records its OS, shell, installed CLI version, package channel, authentication method category and applicable policy. Compare the local built-in help with the versioned release notes; do not copy a command verified only on the other OS. Validate installation and login using the official workflow without sharing credentials. Test a harmless task in a trusted disposable workspace before granting broader access.

**Illustrative prompt — not a shell command:**

> Describe the checks you would perform to confirm this repository's expected development environment. Do not install, update, authenticate, change configuration, or execute commands. Identify assumptions and ask before any action.

Expected result: a proposed checklist for review, not proof that an install or authentication works.

## Troubleshooting and safety

- **Command not found:** check the installation's documented location and shell path, then restart the shell if the installer requires it.
- **Authentication or access denied:** distinguish local login issues from a subscription or organization policy restriction. Use [GitHub's authentication troubleshooting](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/troubleshoot-copilot-cli-auth); do not paste secrets into a support transcript.
- **Startup fails before help:** record the exact error with private paths redacted, installation channel and OS. An executable's presence alone does not prove it runs. In this project's verification environment, package extraction failed with an `EPERM` rename error; no runtime version was obtained.
- **Unexpected update or behavior:** compare the actual version and channel to release notes and managed settings. Do not assume the latest release has the same flags as an older installation.

**Common mistake:** treating a web page's current examples as proof of support in every installed version. Verify local help and feature availability before use.
