# Initial compatibility and model matrix

**Snapshot: 2026-11-11.** CLI 1.0.109 reported its version and help on Windows; no account or interactive behavior was tested. Blank or unknown cells are not evidence of support or absence. Consult current [installation](https://docs.github.com/en/copilot/how-tos/copilot-cli/set-up-copilot-cli/install-copilot-cli), [model selection](https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/choose-a-model) and [plans](https://docs.github.com/en/copilot/get-started/plans).

| Dimension | Documentation baseline | Unverified before release |
|---|---|---|
| Windows | PowerShell 6 or later listed; WinGet and npm channels documented. CLI 1.0.109 version/help ran with a temporary cache on this Windows environment. | Installation procedure, authentication and interactive behavior. |
| macOS | Homebrew, npm and install-script channels documented. | OS/architecture/version matrix and local tests; Homebrew discrepancy V04. |
| Linux | Homebrew, npm and install-script channels documented. | Distribution, architecture, sandbox backend, installation and shell variants. |
| Organization access | CLI policy and applicable seat/plan control access. | This user's entitlement and effective organization settings. |
| Model selection | Models vary by plan and organization/enterprise policy. | Account-specific picker contents, retirement dates and configuration support. |
| Billing | Usage-based AI credits and qualifying legacy request-based billing are distinct. | Actual plan, rates, budgets and charges; refresh [pricing](https://docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing). |
| Managed sandbox | GitHub's current managed settings reference states CLI 1.0.93 or later for the managed `sandbox` setting. | Host support, deployed policy, bypass and enforcement; see V23. |

No named model is assigned a universal rank or entitlement here. The final matrix must record exact identifiers, lifecycle state, context/reasoning controls, plan and policy restrictions, published costs and access date, with each claim sourced and account-specific results labeled separately. No model list or measured benchmark has been validated in this project.

GitHub's [supported models reference](https://docs.github.com/en/copilot/reference/ai-models/supported-models) includes plan and client matrices. Retrieved snapshots differed in freshness and their extracted table markers were incomplete (V29), so blank cells here must not be interpreted as unsupported. Inspect the current rendered source and verify the actual session picker before making model-specific availability claims.
