# GitHub Copilot CLI Advanced Vibe Coding Master Reference

**Work in progress. Verified 2026-11-11: Windows CLI 1.0.109 reports its version and built-in help; interactive behavior remains untested.** The manual is for experienced developers practicing specification-led, supervised software engineering with GitHub Copilot CLI. Availability and behavior can vary with CLI version, platform, account and organizational policy.

This draft distinguishes documentation-backed descriptions from tested behavior. Command examples are **unverified in this environment—do not execute** until checked against the installed version and applicable permissions. Prompts are illustrative task text, not shell commands. The command and configuration catalogs, model matrix, verified integrations and recipe validation are incomplete.

## Draft chapters

1. [F1: Orientation and operating model](docs/fundamentals/01-orientation.md)
2. [F2: Setup and lifecycle](docs/fundamentals/02-setup.md)
3. [F3: Sessions and configuration](docs/fundamentals/03-sessions.md)
4. [C1: Command literacy](docs/commands/01-command-literacy.md)
5. [C2: Repository initialization](docs/commands/02-initialization.md)
6. [C3: Plan to accepted change](docs/commands/03-plan-to-acceptance.md)
7. [C4: Interactive and automation reference](docs/commands/04-operation-reference.md)
8. [M1: Model selection and availability](docs/models/01-selection.md)
9. [M2: Task-based model decisions](docs/models/02-decisions.md)
10. [M3: Repeatable model evaluation](docs/models/03-evaluation.md)
11. [X1: Instructions and discovery](docs/context/01-instructions.md)
12. [X2: Context lifecycle](docs/context/02-context-lifecycle.md)
13. [X3: Task contracts and prompting](docs/context/03-task-contracts.md)
14. [A1: Supervised autonomy](docs/agents/01-supervised-autonomy.md)
15. [A2: Custom agents and delegation](docs/agents/02-custom-agents.md)
16. [A3: End-to-end delivery](docs/agents/03-end-to-end.md)
17. [E1: Choosing an extension mechanism](docs/extensions/01-mechanisms.md)
18. [E2: Extension lifecycle and trust](docs/extensions/02-lifecycle.md)
19. [E3: Toolkit evaluation](docs/extensions/03-toolkit.md)
20. [S1: Permissions and isolation](docs/security/01-permissions-isolation.md)
21. [S2: Threats and incident response](docs/security/02-threats-response.md)
22. [S3: Enterprise governance](docs/security/03-governance.md)
23. [Cookbook contract and status](docs/cookbook/00-recipe-contract.md)
24. [K01–K15: Discovery and planning](docs/cookbook/01-discovery-planning.md)
25. [K16–K30: Brownfield and quality](docs/cookbook/02-brownfield-quality.md)
26. [K31–K45: Modernization and operations](docs/cookbook/03-modernization-operations.md)
27. [K46–K60: Full-stack and AI systems](docs/cookbook/04-fullstack-ai.md)
28. [K61–K80: Context, governance and recovery](docs/cookbook/05-context-recovery.md)

Initial references: [command index](reference/command-index.md), [version 1.0.109 help index](reference/commands-1.0.109.md), [configuration index](reference/configuration-index.md), and [compatibility and model matrix](reference/compatibility-models.md). These are partial documentary indexes, not executable catalogs.

Additional appendix drafts: [extensions](docs/appendices/extensions.md), [security checklist](docs/appendices/security-checklist.md), [prompt and template library](docs/appendices/templates.md), [troubleshooting and FAQ](docs/appendices/troubleshooting.md), and [glossary and topic index](docs/appendices/glossary-index.md).

The [approved architecture](research/gate-2-architecture.md) describes the planned learning path and remaining coverage. See the [source registry](reference/source-registry.md), [verification ledger](reference/verification-ledger.md), [technical QA checkpoint](research/gate-4-technical-qa.md), and [editorial review](research/gate-5-editorial-review.md) for evidence and limitations. This is not a release: the exhaustive catalogs and verified procedures remain incomplete; all recipe workflows, toolkit and security guidance require technical validation.
